package cs3500.music.model;


import java.util.ArrayList;
import java.util.Map;
import java.util.NoSuchElementException;

public class MusicEditorModel implements IMusicEditorModel {
  private Piece piece;

  public MusicEditorModel() {
    this.newPiece();
  }

  @Override
  public void newPiece() {
    this.piece = new Piece();
  }

  @Override
  public void loadPiece(Piece piece) throws NullPointerException {
    if (piece == null) {
      throw new NullPointerException("Given piece is null.");
    }
    this.piece = piece;
  }

  @Override
  public Piece exportPiece() {
    return new Piece(this.piece);
  }

  @Override
  public void addNote(Note note) throws NullPointerException {
    this.piece.addNote(note);
  }

  @Override
  public void removeNote(Note note) throws NullPointerException, NoSuchElementException {
    this.piece.removeNote(note);
  }

  @Override
  public void modifyNote(Note note, Tones tone, int octave, int startingBeat, int beats) throws
          NullPointerException, IllegalArgumentException, NoSuchElementException {
    this.piece.modifyNote(note, tone, octave, startingBeat, beats);
  }

  @Override
  public ArrayList<Note> getNotesAtBeat(int beat) throws IllegalArgumentException {
    if (beat < 0 || beat > this.piece.getMaxBeats()) {
      throw new IllegalArgumentException("beat must be within the beat bounds of the music piece.");
    }
    ArrayList<Note> notesAtBeat = new ArrayList<Note>();
    for (ArrayList<Note> pitchList : this.piece.getAllNotes().values()) {
      for (Note note : pitchList) {
        if (beat >= note.getStartingBeat() && beat <= note.getStartingBeat() + note.getBeats()) {
          notesAtBeat.add(note);
        }
      }
    }
    return notesAtBeat;
  }

  @Override
  public void combinePieceOnTop(Piece other) throws IllegalArgumentException {
    Map<Pitch, ArrayList<Note>> otherNotes = other.getAllNotes();
    for (ArrayList<Note> pitchList : otherNotes.values()) {
      for (Note note : pitchList) {
        this.addNote(note);
      }
    }
  }

  @Override
  public void combinePieceAtEnd(Piece other) {
    // add to dummy to prevent concurrent modification errors
    Piece dummy = new Piece();
    for (ArrayList<Note> pitchList : this.piece.getAllNotes().values()) {
      for (Note note : pitchList) {
        dummy.addNote(note);
      }
    }
    Map<Pitch, ArrayList<Note>> otherNotes = other.getAllNotes();
    for (ArrayList<Note> pitchList : otherNotes.values()) {
      for (Note note : pitchList) {
        dummy.addNote(new Note(note.getPitch().getTone(), note.getPitch().getOctave(), note
                .getStartingBeat() + this.piece.getMaxBeats() + 1, note.getBeats()));
      }
    }
    this.loadPiece(dummy);
  }

  @Override
  public String toString() {
    return this.piece.toString();

  }
}
